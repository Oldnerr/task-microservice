package org.sample.contactservice.event;

public interface PersonEvent {
	
	public String getPersonId();

}
