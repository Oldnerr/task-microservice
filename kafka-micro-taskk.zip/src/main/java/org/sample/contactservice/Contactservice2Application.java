package org.sample.contactservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Contactservice2Application {

	public static void main(String[] args) {
		SpringApplication.run(Contactservice2Application.class, args);
	}

}
