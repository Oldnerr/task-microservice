const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
var swaggerUi = require('swagger-ui-express');
const dbConnection = require('./config/db.config');
const routes = require('./routes');
const { Kafka } = require('kafkajs');
const startConsumer = require('./consumer');

const app = express();

// parse json
app.use(express.json());

// cors
app.use(cors());

// load env vars
// dotenv.config({ path: './config/config.env' });

// connect to database
dbConnection();

// bind routes
app.use('/api/v1', routes);

// start listening to the person events
startConsumer()

// bind swagger
swaggerDocument = require('./docs/swagger.json');
app.use('/swagger', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// listen the server
app.listen(process.env.PORT, () => {
  console.log(`Server is running on port ${process.env.PORT}`);
});