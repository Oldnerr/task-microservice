const { Kafka } = require('kafkajs');

// create the Kafka producer
const kafka = new Kafka({
    clientId: 'order-cloudevents-consumer',
    brokers: ['kafka:9092', 'kafka:9093'],
})

const topics = ['personevents-created', 'personevents-updated', 'personevents-deleted']

// consume to the person events topic
function startConsumer() {
    const consumer = kafka.consumer({ groupId: 'order-events' })
    consumer.connect()
    
    // subscribe to the person events topic
    
    topics.forEach(async (topic) => {
        await consumer.subscribe({ topic })
    })

    consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            console.log({
                value: message.value.toString(),
            })
        },
    })
}

module.exports = startConsumer