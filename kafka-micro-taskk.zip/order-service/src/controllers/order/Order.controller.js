
const asyncWrapper = require("../../helpers/async")
const HTTP_STATUS = require("http-status");
const { CloudEventStrict } = require("cloudevents-kafka");
const { Version } = require("cloudevents");
const { v4: uuid } = require('uuid');
const CeKafka = require("cloudevents-kafka");
const { Kafka } = require("kafkajs");
const { orderService } = require("../../services");

// create the Kafka producer
const kafka = new Kafka({
    clientId: 'order-cloudevents-producer',
    brokers: ['kafka:9092', 'kafka:9093'],
})

const producer = kafka.producer()

const create = asyncWrapper(async (req, res) => {

    const data = await orderService.createOrder(req.body);

    await producer.connect()

    const ce = new CloudEventStrict({
        specversion: Version.V1,
        source: process.env.CLOUD_EVENT_SOURCE,
        id: uuid(),
        type: 'order.create'
    })
    const message = CeKafka.structured(ce)

    const eventCloud = await producer.send({
        topic: 'orderevents-created',
        messages: [
            message,
        ],
    })

    res.status(HTTP_STATUS.CREATED).json(data);
})

const get = asyncWrapper(async (req, res) => {

    const data = await orderService.getOrders();

    res.status(HTTP_STATUS.OK).json(data);
})

const getById = asyncWrapper(async (req, res) => {
    const { orderID } = req.params;

    const data = await orderService.getOrderById(orderID);

    res.status(HTTP_STATUS.OK).json(data);
})

const update = asyncWrapper(async (req, res) => {
    const { orderID } = req.params;

    const data = await orderService.updateOrder(orderID, req.body);

    await producer.connect()

    const ce = new CloudEventStrict({
        specversion: Version.V1,
        source: process.env.CLOUD_EVENT_SOURCE,
        id: uuid(),
        type: 'order.update'
    })
    const message = CeKafka.structured(ce)

    const eventCloud = await producer.send({
        topic: 'orderevents-updated',
        messages: [
            message,
        ],
    })

    res.status(HTTP_STATUS.OK).json(data);
})

const deltaUpdate = asyncWrapper(async (req, res) => {
    const { orderID } = req.params;

    const data = await orderService.deltaUpdateOrder(orderID, req.body);

    await producer.connect()

    const ce = new CloudEventStrict({
        specversion: Version.V1,
        source: process.env.CLOUD_EVENT_SOURCE,
        id: uuid(),
        type: 'order.update'
    })
    const message = CeKafka.structured(ce)

    const eventCloud = await producer.send({
        topic: 'orderevents-updated',
        messages: [
            message,
        ],
    })

    res.status(HTTP_STATUS.OK).json(data);
})

const deleteOrder = asyncWrapper(async (req, res) => {
    const { orderID } = req.params;

    const data = await orderService.deleteOrder(orderID);

    await producer.connect()

    const ce = new CloudEventStrict({
        specversion: Version.V1,
        source: process.env.CLOUD_EVENT_SOURCE,
        id: uuid(),
        type: 'order.delete'
    })
    const message = CeKafka.structured(ce)

    const eventCloud = await producer.send({
        topic: 'orderevents-deleted',
        messages: [
            message,
        ],
    })

    res.status(HTTP_STATUS.NO_CONTENT).json(data);
})

const deleteAllOrders = asyncWrapper(async (req, res) => {
    const data = await orderService.deleteAllOrders();

    await producer.connect()

    const ce = new CloudEventStrict({
        specversion: Version.V1,
        source: process.env.CLOUD_EVENT_SOURCE,
        id: uuid(),
        type: 'order.delete'
    })
    const message = CeKafka.structured(ce)

    const eventCloud = await producer.send({
        topic: 'orderevents-deleted',
        messages: [
            message,
        ],
    })

    res.status(HTTP_STATUS.NO_CONTENT).json(data);
})

module.exports = {
    create,
    get,
    getById,
    update,
    deltaUpdate,
    deleteOrder,
    deleteAllOrders
}