const express = require('express');
const orderController = require('../../controllers/order/Order.controller');

const router = express.Router();

router.get('/', orderController.get);
router.get('/:orderID', orderController.getById);
router.post('/', orderController.create);
router.put('/:orderID', orderController.update);
router.patch('/:orderID', orderController.deltaUpdate);
router.delete('/', orderController.deleteAllOrders);
router.delete('/:orderID', orderController.deleteOrder);

module.exports = router;