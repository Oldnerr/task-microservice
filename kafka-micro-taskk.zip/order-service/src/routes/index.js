const express = require('express');
const orders = require('./order/order')

const router = express.Router();

const orderRoutes = [
    {
      path: '/order',
      route: orders,
    },
];

orderRoutes.forEach((route) => {
    router.use(route.path, route.route);
});

module.exports = router;