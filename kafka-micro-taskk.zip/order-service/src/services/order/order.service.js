const Order = require("../../models/Order.model");
const OrderItem = require("../../models/OrderItem.model");

/**
 * Get all orders
 * @returns {Promise<Array<Order>>}
 */
 const getOrders = async () => {
    const orders = await Order.find();
    return orders;
}

/**
 * Get an order by ID
 * @param {string} orderID - ID of Order to be updated
 * @returns {Promise<Order>}
 */
 const getOrderById = async (orderID) => {
    const order = await Order.findById(orderID);
    return order;
}

/**
 * Create an order
 * @param {string} orderDate - Date of Order Capture
 * @param {string} soldToID - Unique identifier of the person whom the order was sold to
 * @param {string} billToID - Unique identifier of the person whom the order is billed to
 * @param {string} shipToID - Unique identifier of the person whom the order is sold to
 * @param {number} orderValue - Value of the Order incl. taxes
 * @param {number} taxValue - Total taxes of the Order 
 * @param {number} currencyCode - Order Currency
 * @param {Array} items - Items of the order
 * @returns {Promise<Order>}
 */
const createOrder = async (body) => {

    if(body.items.length > 0) {
        const orderItemsPromises = body.items.map(async (item) => {
            const orderItem = await OrderItem.create(item);
            return orderItem._id;
        });
        // const orderItemsIds = await Promise.all(orderItemsPromises);
        // body.items = orderItemsIds;
    }

    const order = await Order.create({...body});
    return order;
}

/**
 * Update an order
 * @param {string} orderID - ID of Order to be updated
 * @param {string} orderDate - Date of Order Capture
 * @param {string} soldToID - Unique identifier of the person whom the order was sold to
 * @param {string} billToID - Unique identifier of the person whom the order is billed to
 * @param {string} shipToID - Unique identifier of the person whom the order is sold to
 * @param {number} orderValue - Value of the Order incl. taxes
 * @param {number} taxValue - Total taxes of the Order 
 * @param {number} currencyCode - Order Currency
 * @param {Array<OrderItem>} items - Items of the order
 * @returns {Promise<Order>}
 */
 const updateOrder = async (orderID, body) => {
    
    /** // because we don't use OrderItem model, we can't use this
     * 
     *  // // Remove previous items
     *   // await OrderItem.deleteMany({
     *   //     $in: body.items
     *   // })
     *   
     *  // // Create new items
     *   // if(body.items.length > 0) {
     *   //     const orderItemsPromises = body.items.map(async (item) => {
     *   //         const orderItem = await OrderItem.create(item);
     *   //         return orderItem._id;
     *   //     });
     *   //     const orderItemsIds = await Promise.all(orderItemsPromises);
     *   // 
     *   //     // body.items = orderItemsIds;
     *   // }
     * 
     * 
     */ 
    
    const order = await Order.findByIdAndUpdate(orderID, { 
        ...body
     });
    return order;
}

/**
 * Delta update of order
 * @param {string} orderID - ID of Order to be updated
 * @param {string} orderDate - Date of Order Capture
 * @param {string} soldToID - Unique identifier of the person whom the order was sold to
 * @param {string} billToID - Unique identifier of the person whom the order is billed to
 * @param {string} shipToID - Unique identifier of the person whom the order is sold to
 * @param {number} orderValue - Value of the Order incl. taxes
 * @param {number} taxValue - Total taxes of the Order 
 * @param {number} currencyCode - Order Currency
 * @param {Array<OrderItem>} items - Items of the order
 * @returns {Promise<Order>}
 */
 const deltaUpdateOrder = async (orderID, body) => {

    /** // because we don't use OrderItem model, we can't use this
     * 
     *  // // Remove previous items
     *   // await OrderItem.deleteMany({
     *   //     $in: body.items
     *   // })
     *   
     *  // // Create new items
     *   // if(body.items.length > 0) {
     *   //     const orderItemsPromises = body.items.map(async (item) => {
     *   //         const orderItem = await OrderItem.create(item);
     *   //         return orderItem._id;
     *   //     });
     *   //     const orderItemsIds = await Promise.all(orderItemsPromises);
     *   // 
     *   //     // body.items = orderItemsIds;
     *   // }
     * 
     * 
     */    

    const order = await Order.findByIdAndUpdate(orderID, { 
        ...body
     });
    return order;
}

/**
 * Delete an order
 * @param {string} orderID - ID of Order to be updated
 * @returns {Object}
 */
 const deleteOrder = async (orderID) => {
    
    // delete order items
    const order = await Order.findById(orderID);

    if(order.items.length > 0) {
        await OrderItem.deleteMany({
            _id: {
                $in: order.items
            }
        })
    }

    await Order.deleteOne({ orderID });
    
    return
}

/**
 * Delete all orders
 * @returns {Object}
 */
 const deleteAllOrders = async () => {

    // delete order items
    const orders = await Order.find();

    if(orders.length > 0) {
        orders.forEach(async (order) => {
            if(order.items.length > 0) {
                await OrderItem.deleteMany({
                    _id: {
                        $in: order.items
                    }
                })
            }
        })
    }

    await Order.deleteMany({});
    return
}

module.exports = {
    createOrder,
    getOrders,
    getOrderById,
    updateOrder,
    deltaUpdateOrder,
    deleteOrder,
    deleteAllOrders
}