module.exports = {
    orderService: require('./order/order.service'),
}