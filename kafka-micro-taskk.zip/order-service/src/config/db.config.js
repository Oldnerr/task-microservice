const mongoose = require('mongoose');
module.exports = () => {
   mongoose.connect(`${process.env.MONGODB_URI}/${process.env.MONGODB_DATABASE}`,{ useNewUrlParser: true ,useUnifiedTopology: true })
    mongoose.connection.on('open',() => {
        console.log('DB connected')
      });
      mongoose.connection.on('error',(err) => {
        console.log('DB Disconnected',err)
      });

    mongoose.Promise = global.Promise;
}