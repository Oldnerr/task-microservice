const mongoose = require('mongoose');

const personSchema = mongoose.Schema(
  {
    city: {
      type: String,
      required: true,
    },
    country: {
      type: String,
      required: true,
    },
    extensionFields: {
      type: Object,
      required: true,
    },
    firstName: {
      type: String,
      required: true,
    },
    houseNumber: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    streetAddress: {
      type: String,
      required: true,
    },
    zip: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

/**
 * @typedef Person
 */
const Person = mongoose.model('Person', personSchema);

module.exports = Person;