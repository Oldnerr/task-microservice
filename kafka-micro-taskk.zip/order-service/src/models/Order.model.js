const mongoose = require('mongoose');

const orderSchema = mongoose.Schema(
  {
    orderDate: {
      type: String,
      required: true,
    },
    soldTo: {
      // type: mongoose.Types.ObjectId,
      // ref: 'Person',
      type: String,
      required: true,
    },
    billTo: {
      // type: mongoose.Types.ObjectId,
      // ref: 'Person',
      type: String,
      required: true,
    },
    shipTo: {
      // type: mongoose.Types.ObjectId,
      // ref: 'Person',
      type: String,
      required: true,
    },
    orderValue: {
        type: Number,
        required: true,
    },
    taxValue: {
        type: Number,
        required: true,
    },
    currencyCode: {
        type: String,
        required: true,
    },
    items: [
      {
        // type: mongoose.Types.ObjectId,
        // ref: 'OrderItem',
        type: Object,
        required: true,
      }
    ]
  },
  {
    timestamps: true,
  }
);

/**
 * @typedef Order
 */
const Order = mongoose.model('Order', orderSchema);

module.exports = Order;