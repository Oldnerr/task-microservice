const mongoose = require('mongoose');

const orderItemSchema = mongoose.Schema(
  {
    itemID: {
      type: String,
      required: true,
    },
    productID: {
      type: String,
      required: true,
    },
    quantity: {
      type: String,
      required: true,
    },
    itemPrice: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

/**
 * @typedef OrderItem
 */
const OrderItem = mongoose.model('OrderItem', orderItemSchema);

module.exports = OrderItem;