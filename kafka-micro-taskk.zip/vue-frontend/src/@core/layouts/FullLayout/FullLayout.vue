<script setup >
    import { defineComponent } from 'vue';
    defineComponent({
        name: "FullLayout"
    })

</script>

<template>
    <div>
        <!-- navbar -->
        slot
        <slot></slot>

        <!-- footer -->
    </div>
</template>