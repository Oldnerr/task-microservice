<script setup>
import { onBeforeMount, ref } from 'vue';
import axios from 'axios'
import AddOrder from './components/AddOrder.vue'
import UpdateOrder from './components/UpdateOrder.vue'

const data = ref([])
const isAddOrderModalOpen = ref(false)
const isLoading = ref(false)
const selectedOrder = ref(null)
const isUpdateModeOn = ref(false)

const getData = async () => {
  if(isAddOrderModalOpen.value) {
    isAddOrderModalOpen.value = false
  }

  isLoading.value = true

  const response = await axios.get('http://localhost:8081/api/v1/order', {
    headers: {
      'Content-Type': 'application/json',
    }
  })

  data.value = response.data

  setTimeout(() => {
    isLoading.value = false
  }, 400);
}

const startUpdateMode = (order) => {
  selectedOrder.value = order
  setTimeout(() => {
    isUpdateModeOn.value = true
  }, 300);
  isAddOrderModalOpen.value = true
}

async function removeItem(id) {
  await axios.delete(`http://localhost:8081/api/v1/order/${id}`, {
    headers: {
      'Content-Type': 'application/json',
    }
  })

  getData()
}

async function removeAllItems(id) {
  await axios.delete(`http://localhost:8081/api/v1/order`, {
    headers: {
      'Content-Type': 'application/json',
    }
  })

  getData()
}

onBeforeMount(getData)

</script>

<template>
  <div class="mx-auto mt-4">
    <div class="d-flex justify-end mb-6">
      <v-btn
        class="mr-4"
        color="red"
        @click="removeAllItems"
      >
        <v-icon>mdi-delete</v-icon>
        Delete all orders
      </v-btn>
      <v-btn
        variant="outlined"
        color="primary"
        @click="isAddOrderModalOpen = true"
      >
        <v-icon>mdi-plus</v-icon>
        Create Order
      </v-btn>
    </div>
      <v-table>
        <thead>
          <tr>
            <th class="text-left">#</th>
            <th class="text-left">orderDate</th>
            <th class="text-left">soldTo</th>
            <th class="text-left">billTo</th>
            <th class="text-left">shipTo</th>
            <th class="text-left">orderValue</th>
            <th class="text-left">taxValue</th>
            <th class="text-left">currencyCode</th>
            <th class="text-left">items length</th>
            <th class="text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in data" :key="item.id">
            <td>{{ item._id }}</td>
            <td>{{ item.orderDate }}</td>
            <td>{{ item.soldTo }}</td>
            <td>{{ item.billTo }}</td>
            <td>{{ item.shipTo }}</td>
            <td>{{ item.orderValue }}</td>
            <td>{{ item.taxValue }}</td>
            <td>{{ item.currencyCode }}</td>
            <td>{{ item.items.length || 0 }}</td>
            <td>
              <v-btn
                  variant="outlined"
                  size="small"
                  icon
                  color="info"
                >
                  <v-icon>mdi-pencil</v-icon>
                  <v-menu activator="parent">
                    <v-list>
                      <v-list-item>
                        <v-list-item-title @click="startUpdateMode(item)">Update</v-list-item-title>
                      </v-list-item>
                      <v-list-item>
                        <v-list-item-title @click="removeItem(item._id)">Delete</v-list-item-title>
                      </v-list-item>
                    </v-list>
                  </v-menu>
                </v-btn>
            </td>
          </tr>
          <v-overlay v-model="isLoading" contained class="align-center justify-center">
            <v-progress-circular
                indeterminate
                size="64"
                color="primary"
              ></v-progress-circular>
          </v-overlay>
        </tbody>
      </v-table>
      <v-dialog
        v-model="isAddOrderModalOpen"
        max-width="900px"
        scrollable
      >
        <AddOrder v-if="!isUpdateModeOn" @getData="getData" />
        <UpdateOrder v-else @getData="getData" :selected-order="selectedOrder" />
      </v-dialog>
    </div>
</template>
