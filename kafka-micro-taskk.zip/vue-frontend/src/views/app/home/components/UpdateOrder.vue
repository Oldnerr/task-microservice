<script setup>
import { onBeforeMount, ref } from 'vue';
import axios from 'axios'
const emit = defineEmits(['getData', 'get'])
const props = defineProps(['selectedOrder'])

const formData = ref({
    orderDate: '',
    soldTo: '',
    billTo: '',
    shipTo: '',
    orderValue: '',
    taxValue: '',
    currencyCode: '',
    items: []
})

function addOrderItem() {
    formData.value.items.push({
        itemID: '',
        productID: '',
        quantity: '',
        itemPrice: '',
    })
}

async function submit() {
    await axios.patch(`http://localhost:8081/api/v1/order/${props.selectedOrder._id}`, formData.value, {
        headers: {
            'Content-Type': 'application/json',
        }
    })

    emit('getData')
}

async function getDetail() {
    const response = await axios.get(`http://localhost:8081/api/v1/order/${props.selectedOrder._id}`, {
        headers: {
            'Content-Type': 'application/json',
        }
    })

    console.log(response.data)

    formData.value = response.data
}

onBeforeMount(getDetail)

</script>


<template>

    <v-card>
        <v-card-title>
            <span class="text-h5">User Profile</span>
        </v-card-title>
        <v-card-text>
            <v-container>
                <v-row>
                    <v-col cols="12">
                        <v-text-field label="orderDate" required v-model="formData.orderDate"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="4">
                        <v-text-field label="soldToID*" required v-model="formData.soldTo"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="4">
                        <v-text-field label="billToID*" required v-model="formData.billTo"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="4">
                        <v-text-field label="shipToID*" required v-model="formData.shipTo"></v-text-field>
                    </v-col>
                    <v-col cols="12">
                        <v-text-field type="number" label="orderValue*" required v-model="formData.orderValue"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6">
                        <v-text-field type="number" label="taxValue*" required v-model="formData.taxValue"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6">
                        <v-text-field label="currencyCode*" required v-model="formData.currencyCode"></v-text-field>
                    </v-col>
                    <v-divider></v-divider>
                    <v-col cols="12">
                        <v-btn variant="outlined" color="primary" block @click="addOrderItem">
                            Add Order Item
                        </v-btn>
                    </v-col>
                </v-row>
                <div v-if="formData.items.length">
                    <v-row v-for="(orderItem, index) in formData.items" :key="index + '-order-item'" class="align-center">
                        <span>{{( index + 1 + '.')}}</span>
                        <v-col type="number" cols="6" sm="2">
                            <v-text-field label="itemID*" required
                                v-model="formData.items[index].itemID"></v-text-field>
                        </v-col>
                        <v-col type="number" cols="6" sm="3">
                            <v-text-field label="productID*" required
                                v-model="formData.items[index].productID"></v-text-field>
                        </v-col>
                        <v-col type="number" cols="6" sm="3">
                            <v-text-field label="quantity*" required
                                v-model="formData.items[index].quantity"></v-text-field>
                        </v-col>
                        <v-col type="number" cols="6" sm="3">
                            <v-text-field label="itemPrice*" required
                                v-model="formData.items[index].itemPrice"></v-text-field>
                        </v-col>
                        <v-btn
                        icon="mdi-delete"
                        color="red"
                        size="small"
                        @click="formData.items.splice(index, 1)"
                        ></v-btn>
                    </v-row>
                </div>
            </v-container>
            <small>*indicates required field</small>
        </v-card-text>
        <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn @click="emit('getData')" color="blue-darken-1" variant="text">
                Close
            </v-btn>
            <v-btn @click="submit" color="blue-darken-1" variant="text">
                Submit
            </v-btn>
        </v-card-actions>
    </v-card>

</template>