<script setup>
import { ref, watch, markRaw } from "vue";
import { RouterView, useRoute } from "vue-router";
// import FullLayout from "./layouts/FullLayout.vue";

// const route = useRoute()

// const layout = ref()

// const layout = computed(() => route.meta.layout || defaultLayout.value)

/** Watch for the route to detect current layout from route.meta.layout */
// watch(
//   () => route.meta.layout,
//   async (metaLayout) => {
//     try {
//       const component = metaLayout && await import(`@layouts/${metaLayout}.vue`)
//       layout.value = markRaw(component?.default || FullLayout)
//     } catch (e) {
//       layout.value = markRaw(FullLayout)
//     }
//   },
//   { immediate: true }
// )
</script>

<template>
  <!-- <component :is="layout"> -->
    <v-layout>
      <RouterView />
    </v-layout>
  <!-- </component> -->
</template>

<style scoped>
</style>
