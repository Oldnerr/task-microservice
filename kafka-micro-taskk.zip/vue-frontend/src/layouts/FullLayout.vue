<script setup>
import FullLayout from '@core/layouts/FullLayout/FullLayout.vue'
</script>

<template>
    <FullLayout />
</template>