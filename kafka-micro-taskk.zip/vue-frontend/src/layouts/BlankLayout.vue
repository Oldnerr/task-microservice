<script setup>
import BlankLayout from '@core/layouts/BlankLayout/BlankLayout.vue'
</script>

<template>
    <div class="blank-layout">
        <BlankLayout />
    </div>
</template>